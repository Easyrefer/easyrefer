import React, { useState } from "react";
import JobForm from "./components/JobForm";
import './App.css';

function App() {
  return (
    <div className="app">
      <header>
        <h1>EasyRefer</h1>
        <p>Your simple referral-based job platform</p>
      </header>
      <main>
        <JobForm />
      </main>
    </div>
  );
}

export default App;
