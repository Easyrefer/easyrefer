import React, { useState } from "react";

function JobForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    jobRole: "",
    location: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch("https://v1.nocodeapi.com/easyrefer/google_sheets/DBeTXNBuPXEvuDUb", {
      method: "POST",
      body: JSON.stringify([Object.values(formData)]),
      headers: {
        "Content-Type": "application/json"
      }
    });
    if (res.ok) alert("Submitted successfully!");
    else alert("Error submitting data");
  };

  return (
    <form className="job-form" onSubmit={handleSubmit}>
      <input name="name" placeholder="Your Name" onChange={handleChange} required />
      <input name="email" placeholder="Email" onChange={handleChange} required />
      <input name="company" placeholder="Company" onChange={handleChange} required />
      <input name="jobRole" placeholder="Job Role" onChange={handleChange} required />
      <input name="location" placeholder="Location" onChange={handleChange} required />
      <button type="submit">Submit</button>
    </form>
  );
}

export default JobForm;
